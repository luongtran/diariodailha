//@line 2 "/srv/build-trees/build-alpha/i686/firefox-10.0.10esr/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
